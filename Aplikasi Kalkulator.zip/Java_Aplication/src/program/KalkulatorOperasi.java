/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program;

public abstract class KalkulatorOperasi implements OperasiMatematika {
    protected double bil1; //as atribut and encapsulation
    protected double bil2;

    public KalkulatorOperasi(double bil1, double bil2) { //as konstruktor 
        this.bil1 = bil1;
        this.bil2 = bil2;
    }
}