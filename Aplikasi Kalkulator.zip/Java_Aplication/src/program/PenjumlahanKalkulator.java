/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program;

public class PenjumlahanKalkulator extends KalkulatorOperasi {
    public PenjumlahanKalkulator(double bil1, double bil2) {
        super(bil1, bil2);
    }

    @Override
    public double hitung(double bil1, double bil2) {
        return bil1 + bil2;
    }
}
