/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program;

public class PembagianKalkulator extends KalkulatorOperasi {
    public PembagianKalkulator(double bil1, double bil2) {
        super(bil1, bil2);
    }

    @Override
    public double hitung(double bil1, double bil2) {
        if (bil2 != 0) {
            return bil1 / bil2;
        } else {
            System.out.println("Error: Pembagian oleh nol.");
            return Double.NaN; // NaN (Not a Number) untuk menunjukkan hasil yang tidak valid.
        }
    }
}
